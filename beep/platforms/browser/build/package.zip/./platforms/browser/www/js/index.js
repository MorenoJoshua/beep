var app = {
    initialize: function () {
        document.addEventListener('deviceready', this.onDeviceReady.bind(this), false);
    },

    onDeviceReady: function () {
    },

    receivedEvent: function (id) {
    }
};

app.initialize();