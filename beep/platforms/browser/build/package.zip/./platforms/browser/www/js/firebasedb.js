// Initialize Firebase
// TODO: Replace with your project's customized code snippet
var config = {
    apiKey: "AIzaSyDacq6TH6d3K0K6NcLXjdBgNBsG3ISWLG4",
    authDomain: "project-2124564468572248429.firebaseapp.com",
    databaseURL: "https://project-2124564468572248429.firebaseio.com/",
    storageBucket: "project-2124564468572248429.appspot.com",
    messagingSenderId: "409782143952",
};
firebase.initializeApp(config);